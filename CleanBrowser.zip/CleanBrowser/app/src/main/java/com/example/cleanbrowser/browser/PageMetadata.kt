package com.example.cleanbrowser.browser

import android.webkit.WebView
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

data class PageInfo(val title: String, val author: String, val site: String, val host: String)

/** Reads the video's full title, channel/creator and site name from the loaded page, then builds a file name. */
object PageMetadata {

    private const val MAX_NAME = 120

    // Runs inside the page. Tries Open Graph, JSON-LD (VideoObject), YouTube player data and common meta tags.
    private const val JS = """
    (function(){
      function m(sel){var e=document.querySelector(sel);
        return e?((e.content||e.getAttribute('content')||e.textContent||'')+'').trim():'';}
      var host=location.hostname.replace(/^www\./,'');
      var title=m('meta[property="og:title"]')||m('meta[name="twitter:title"]')||document.title||'';
      var author='';
      try{
        var ls=document.querySelectorAll('script[type="application/ld+json"]');
        for(var i=0;i<ls.length&&!author;i++){
          var d=JSON.parse(ls[i].textContent);
          var arr=Array.isArray(d)?d:(d['@graph']||[d]);
          for(var j=0;j<arr.length&&!author;j++){
            var a=arr[j]&&(arr[j].author||arr[j].creator||arr[j].uploader);
            if(Array.isArray(a))a=a[0];
            if(a)author=(typeof a==='string'?a:a.name)||'';
          }
        }
      }catch(e){}
      if(!author){try{author=ytInitialPlayerResponse.videoDetails.author||'';}catch(e){}}
      if(!author)author=m('[itemprop="author"] [itemprop="name"]')||m('meta[name="author"]')
        ||m('meta[property="article:author"]')||m('meta[name="twitter:creator"]');
      author=author.replace(/^@/,'');
      var site=m('meta[property="og:site_name"]')||host;
      return JSON.stringify({title:title,author:author,site:site,host:host});
    })()
    """

    /** Must be called on the main thread. Returns null if the page can't be read in time. */
    suspend fun read(wv: WebView?): PageInfo? = withTimeoutOrNull(3000) {
        if (wv == null) return@withTimeoutOrNull null
        suspendCancellableCoroutine<PageInfo?> { cont ->
            wv.evaluateJavascript(JS) { raw ->
                val info = runCatching {
                    val str = JSONTokener(raw).nextValue() as? String ?: return@runCatching null
                    val o = JSONObject(str)
                    PageInfo(o.optString("title"), o.optString("author"), o.optString("site"), o.optString("host"))
                }.getOrNull()
                if (cont.isActive) cont.resume(info)
            }
        }
    }

    /** "Full title - Channel - Site". Site is always last; the title is trimmed first if too long. */
    fun buildName(info: PageInfo): String {
        var title = info.title.trim()
        // Drop a trailing " - YouTube" / " | site.com" the page already appended to its own title.
        for (s in listOf(info.site, info.host).filter { it.isNotBlank() }) {
            title = title.replace(
                Regex("\\s*[-–—|·:]\\s*" + Regex.escape(s) + "\\s*$", RegexOption.IGNORE_CASE), ""
            )
        }
        val tail = mutableListOf<String>()
        if (info.author.isNotBlank() && !title.contains(info.author, ignoreCase = true)) tail += info.author.trim()
        if (info.site.isNotBlank() && !info.site.equals(info.author, ignoreCase = true)) tail += info.site.trim()

        val suffix = tail.joinToString(" - ")
        val room = (MAX_NAME - suffix.length - 3).coerceAtLeast(20)
        title = title.take(room).trim()
        return (listOf(title) + tail).filter { it.isNotBlank() }.joinToString(" - ")
    }
}
