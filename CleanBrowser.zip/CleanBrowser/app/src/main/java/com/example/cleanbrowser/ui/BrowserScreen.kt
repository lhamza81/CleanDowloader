package com.example.cleanbrowser.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.cleanbrowser.BrowserViewModel
import com.example.cleanbrowser.browser.BrowserTab
import com.example.cleanbrowser.browser.DetectedVideo
import com.example.cleanbrowser.browser.TabManager
import com.example.cleanbrowser.download.Downloader

private enum class Screen { Browser, Tabs, Downloads }

@Composable
fun BrowserScreen(vm: BrowserViewModel = viewModel()) {
    val mgr = vm.tabManager
    val ctx = LocalContext.current
    val fullscreenView = mgr.customView
    var screen by remember { mutableStateOf(Screen.Browser) }

    BackHandler(enabled = fullscreenView == null && screen != Screen.Browser) { screen = Screen.Browser }
    BackHandler(enabled = fullscreenView == null && screen == Screen.Browser && mgr.activeTab?.canGoBack == true) { mgr.goBack() }

    Box(Modifier.fillMaxSize()) {
        when (screen) {
            Screen.Tabs -> TabSwitcher(
                tabs = mgr.tabs,
                activeId = mgr.activeId,
                onSelect = { mgr.select(it); screen = Screen.Browser },
                onClose = { mgr.closeTab(it) },
                onNew = {
                    if (mgr.newTab()) screen = Screen.Browser
                    else Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                },
                onDismiss = { screen = Screen.Browser },
            )
            Screen.Downloads -> DownloadsScreen(onBack = { screen = Screen.Browser })
            Screen.Browser -> BrowserContent(
                mgr = mgr,
                onTabs = { screen = Screen.Tabs },
                onDownloads = { screen = Screen.Downloads },
            )
        }
        // Overlay (not a replacement) so the WebView stays attached and playback continues.
        if (fullscreenView != null) FullscreenVideo(fullscreenView, onExit = mgr::exitFullscreen)
    }
}

@Composable
private fun BrowserContent(mgr: TabManager, onTabs: () -> Unit, onDownloads: () -> Unit) {
    val ctx = LocalContext.current
    val tab = mgr.activeTab
    var showVideos by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<DetectedVideo?>(null) }

    Scaffold(
        topBar = {
            Column(Modifier.statusBarsPadding()) {
                TabStrip(
                    tabs = mgr.tabs,
                    activeId = mgr.activeId,
                    onSelect = { mgr.select(it) },
                    onClose = { mgr.closeTab(it) },
                    onNew = {
                        if (!mgr.newTab()) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                    },
                )
                if (tab != null) AddressBar(tab, onGo = { mgr.load(it) })
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = false, enabled = tab?.canGoBack == true, onClick = { mgr.goBack() },
                    icon = { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") },
                )
                NavigationBarItem(
                    selected = false, enabled = tab?.canGoForward == true, onClick = { mgr.goForward() },
                    icon = { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Forward") },
                )
                NavigationBarItem(
                    selected = false, onClick = { mgr.load(TabManager.HOME) },
                    icon = { Icon(Icons.Filled.Home, "Home") },
                )
                NavigationBarItem(
                    selected = false, onClick = onTabs,
                    icon = {
                        Box(
                            Modifier.size(24.dp).border(2.dp, MaterialTheme.colorScheme.onSurfaceVariant, RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center,
                        ) { Text("${mgr.tabs.size}", style = MaterialTheme.typography.labelSmall) }
                    },
                )
                NavigationBarItem(
                    selected = false, onClick = onDownloads,
                    icon = { Icon(Icons.Filled.Download, "Downloads") },
                )
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (tab != null) {
                key(tab.id) {
                    AndroidView(factory = { mgr.webViewFor(tab) }, modifier = Modifier.fillMaxSize())
                }
                if (tab.progress in 1..99) {
                    LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
                }
                if (tab.videos.isNotEmpty()) {
                    ExtendedFloatingActionButton(
                        onClick = { showVideos = true },
                        icon = { Icon(Icons.Filled.Download, null) },
                        text = { Text("${tab.videos.size} video${if (tab.videos.size > 1) "s" else ""}") },
                        modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                    )
                }
            }
        }
    }

    if (showVideos && tab != null) {
        VideoListDialog(
            videos = tab.videos,
            pageUrl = tab.url,
            pageTitle = tab.title,
            userAgent = mgr.userAgent,
            webView = mgr.activeWebView(),
            onDismiss = { showVideos = false },
            onPick = { pending = it; showVideos = false },
            onDownloadAll = { items ->
                items.forEach { (option, name) -> Downloader.enqueue(ctx, option, tab.url, mgr.userAgent, name) }
                Toast.makeText(ctx, "Downloading ${items.size} video${if (items.size > 1) "s" else ""}", Toast.LENGTH_SHORT).show()
                showVideos = false
            },
        )
    }

    mgr.linkMenu?.let { link ->
        AlertDialog(
            onDismissRequest = mgr::dismissLinkMenu,
            title = { Text(link, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall) },
            text = {
                Column {
                    ListItem(
                        headlineContent = { Text("Open in new tab") },
                        leadingContent = { Icon(Icons.Filled.Add, null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable {
                            if (!mgr.newTab(link)) Toast.makeText(ctx, "Tab limit reached (${TabManager.MAX_TABS})", Toast.LENGTH_SHORT).show()
                            mgr.dismissLinkMenu()
                        },
                    )
                    ListItem(
                        headlineContent = { Text("Copy link") },
                        leadingContent = { Icon(Icons.Filled.ContentCopy, null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        modifier = Modifier.clickable {
                            ctx.getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("link", link))
                            mgr.dismissLinkMenu()
                        },
                    )
                }
            },
            confirmButton = { TextButton(onClick = mgr::dismissLinkMenu) { Text("Cancel") } },
        )
    }

    val picked = pending
    if (picked != null && tab != null) {
        DownloadOptionsDialog(
            video = picked,
            pageUrl = tab.url,
            pageTitle = tab.title,
            userAgent = mgr.userAgent,
            webView = mgr.activeWebView(),
            onDismiss = { pending = null },
        ) { option, name ->
            Downloader.enqueue(ctx, option, tab.url, mgr.userAgent, name)
            Toast.makeText(ctx, "Download started", Toast.LENGTH_SHORT).show()
            pending = null
        }
    }
}

@Composable
private fun AddressBar(tab: BrowserTab, onGo: (String) -> Unit) {
    val focus = LocalFocusManager.current
    var text by remember(tab.id, tab.url) { mutableStateOf(tab.url) }
    TextField(
        value = text,
        onValueChange = { text = it },
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
        colors = TextFieldDefaults.colors(
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
        ),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
        keyboardActions = KeyboardActions(onGo = { onGo(text); focus.clearFocus() }),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

@Composable
private fun FullscreenVideo(view: View, onExit: () -> Unit) {
    val activity = LocalContext.current as Activity
    BackHandler(onBack = onExit)
    DisposableEffect(Unit) {
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller.show(WindowInsetsCompat.Type.systemBars()) }
    }
    AndroidView(
        factory = { (view.parent as? ViewGroup)?.removeView(view); view },
        modifier = Modifier.fillMaxSize().background(Color.Black),
    )
}
