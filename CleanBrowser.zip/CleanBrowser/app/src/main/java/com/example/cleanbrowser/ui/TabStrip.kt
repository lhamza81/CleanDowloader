package com.example.cleanbrowser.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.BrowserTab

/** Tabs side by side in one scrollable row, like Chrome and Firefox. */
@Composable
fun TabStrip(
    tabs: List<BrowserTab>,
    activeId: Int,
    onSelect: (Int) -> Unit,
    onClose: (Int) -> Unit,
    onNew: () -> Unit,
) {
    val listState = rememberLazyListState()
    LaunchedEffect(activeId, tabs.size) {
        val i = tabs.indexOfFirst { it.id == activeId }
        if (i >= 0) listState.animateScrollToItem(i)
    }

    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainerHigh),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LazyRow(
            modifier = Modifier.weight(1f),
            state = listState,
            contentPadding = PaddingValues(start = 6.dp, end = 2.dp, top = 6.dp, bottom = 0.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(tabs, key = { it.id }) { tab ->
                TabChip(tab, active = tab.id == activeId, onSelect = { onSelect(tab.id) }, onClose = { onClose(tab.id) })
            }
        }
        IconButton(onClick = onNew) { Icon(Icons.Filled.Add, "New tab") }
    }
}

@Composable
private fun TabChip(tab: BrowserTab, active: Boolean, onSelect: () -> Unit, onClose: () -> Unit) {
    Row(
        modifier = Modifier
            .width(150.dp)
            .height(38.dp)
            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
            .background(if (active) MaterialTheme.colorScheme.surface else Color.Transparent)
            .clickable(onClick = onSelect)
            .padding(start = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val icon = tab.favicon
        if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(16.dp))
        else Icon(Icons.Filled.Public, null, Modifier.size(16.dp))
        Text(
            tab.title,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelMedium,
        )
        IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Filled.Close, "Close tab", Modifier.size(14.dp))
        }
    }
}
