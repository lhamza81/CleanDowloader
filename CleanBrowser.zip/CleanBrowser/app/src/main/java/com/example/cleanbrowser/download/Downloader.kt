package com.example.cleanbrowser.download

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.widget.Toast
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.example.cleanbrowser.browser.QualityOption

object Downloader {

    /** Starts the download for the chosen quality under the user's file name. */
    fun enqueue(ctx: Context, option: QualityOption, pageUrl: String, userAgent: String, rawName: String) {
        val name = safeName(rawName.removeSuffix(".mp4")).ifBlank { "video_${System.currentTimeMillis()}" }
        if (option.isHls) enqueueHls(ctx, option.url, pageUrl, userAgent, name)
        else enqueueMp4(ctx, option.url, pageUrl, userAgent, name)
    }

    /** Direct .mp4: DownloadManager handles background, retries and the notification. */
    private fun enqueueMp4(ctx: Context, url: String, pageUrl: String, userAgent: String, name: String) {
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setTitle(name)
            setMimeType("video/mp4")
            addRequestHeader("User-Agent", userAgent)
            addRequestHeader("Referer", pageUrl)
            CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "$name.mp4")
        }
        ctx.getSystemService(DownloadManager::class.java).enqueue(request)
    }

    /** HLS: WorkManager job downloads the chosen variant's segments and remuxes them to MP4. */
    private fun enqueueHls(ctx: Context, url: String, pageUrl: String, userAgent: String, name: String) {
        val req = OneTimeWorkRequestBuilder<HlsDownloadWorker>()
            .setInputData(workDataOf(
                HlsDownloadWorker.K_URL to url,
                HlsDownloadWorker.K_REFERER to pageUrl,
                HlsDownloadWorker.K_UA to userAgent,
                HlsDownloadWorker.K_NAME to name,
            ))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .addTag(HlsDownloadWorker.TAG)
            .addTag("name:$name")
            .build()
        WorkManager.getInstance(ctx).enqueue(req)
    }

    fun openVideo(ctx: Context, uri: Uri) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "No video player installed", Toast.LENGTH_SHORT).show()
        }
    }

    /** Removes only characters Android/filesystems reject, so titles keep their punctuation and Unicode. */
    private fun safeName(s: String) = s
        .replace(":", " -").replace("|", "-")
        .replace(Regex("[\\\\/*?\"<>\\p{Cntrl}]"), "")
        .replace(Regex("\\s+"), " ")
        .trim().trim('.').take(150).trim()

}
