package com.example.cleanbrowser.browser

import android.graphics.Bitmap
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class DetectedVideo(val url: String, val isHls: Boolean)

/** UI-observable state for one tab. The WebView itself lives in [TabManager]. */
class BrowserTab(val id: Int, initialUrl: String) {
    var url by mutableStateOf(initialUrl)
    var title by mutableStateOf("New tab")
    var favicon by mutableStateOf<Bitmap?>(null)
    var progress by mutableIntStateOf(0)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    val videos = mutableStateListOf<DetectedVideo>()

    /** Back/forward list + scroll, stored when the WebView is freed to save memory. */
    var savedState: Bundle? = null

    /** Created for window.open()/target=_blank: its WebView must start unused. */
    var isPopup = false

    fun addVideo(v: DetectedVideo) {
        if (videos.none { it.url == v.url } && videos.size < 20) videos.add(v)
    }
}
