package com.example.cleanbrowser.ui

import android.net.Uri
import android.webkit.WebView
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.DetectedVideo
import com.example.cleanbrowser.browser.PageInfo
import com.example.cleanbrowser.browser.PageMetadata
import com.example.cleanbrowser.browser.QualityOption
import com.example.cleanbrowser.browser.VideoProbe

/** Shows the full file name and the available qualities. Buttons: Cancel | Rename | Download. */
@Composable
fun DownloadOptionsDialog(
    video: DetectedVideo,
    pageUrl: String,
    pageTitle: String,
    userAgent: String,
    webView: WebView?,
    onDismiss: () -> Unit,
    onConfirm: (QualityOption, String) -> Unit,
) {
    // Starts from title + site, then upgrades to "Title - Channel - Site" once the page is read.
    var name by remember(video.url) {
        val host = Uri.parse(pageUrl).host.orEmpty().removePrefix("www.")
        mutableStateOf(PageMetadata.buildName(PageInfo(pageTitle.ifBlank { "video" }, "", host, host)))
    }
    var edited by remember(video.url) { mutableStateOf(false) }
    var editing by remember(video.url) { mutableStateOf(false) }
    var options by remember(video.url) { mutableStateOf<List<QualityOption>?>(null) }
    var selected by remember(video.url) { mutableIntStateOf(0) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(video.url) {
        val info = PageMetadata.read(webView)
        if (info != null && !edited) PageMetadata.buildName(info).takeIf { it.isNotBlank() }?.let { name = it }
    }
    LaunchedEffect(video.url) { options = VideoProbe.probe(video, userAgent, pageUrl) }
    LaunchedEffect(editing) { if (editing) focus.requestFocus() }

    // Download is always possible: until detection finishes we fall back to the original URL.
    val fallback = QualityOption("Original quality", video.url, video.isHls)
    val choice = options?.getOrNull(selected) ?: fallback

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Download video") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("File name", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (editing) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it; edited = true },
                            suffix = { Text(".mp4") },
                            minLines = 1,
                            maxLines = 5,
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        )
                    } else {
                        // Full name, wrapped over as many lines as needed.
                        Text("$name.mp4", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    }
                }

                Text("Quality", style = MaterialTheme.typography.labelLarge)
                val list = options
                if (list == null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("Detecting available qualities…", modifier = Modifier.padding(start = 12.dp))
                    }
                } else {
                    list.forEachIndexed { i, q ->
                        Row(
                            Modifier.fillMaxWidth().clickable { selected = i },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = selected == i, onClick = { selected = i })
                            Column(Modifier.padding(start = 4.dp)) {
                                Text(q.label)
                                q.detail?.let {
                                    Text(it, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        },
        // AlertDialog lays these out left to right: Cancel, then the confirm slot (Rename, Download).
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        confirmButton = {
            Row {
                TextButton(onClick = { editing = !editing }) { Text(if (editing) "Done" else "Rename") }
                TextButton(onClick = { onConfirm(choice, name) }) { Text("Download") }
            }
        },
    )
}
