package com.example.cleanbrowser.ui

import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cleanbrowser.browser.DetectedVideo
import com.example.cleanbrowser.browser.Fmt
import com.example.cleanbrowser.browser.PageInfo
import com.example.cleanbrowser.browser.PageMetadata
import com.example.cleanbrowser.browser.QualityOption
import com.example.cleanbrowser.browser.VideoProbe
import kotlinx.coroutines.launch

/** All videos found on the page in one place, with the total size and a single "Download all". */
@Composable
fun VideoListDialog(
    videos: List<DetectedVideo>,
    pageUrl: String,
    pageTitle: String,
    userAgent: String,
    webView: WebView?,
    onDismiss: () -> Unit,
    onPick: (DetectedVideo) -> Unit,
    onDownloadAll: (List<Pair<QualityOption, String>>) -> Unit,
) {
    val probes = remember { mutableStateMapOf<String, List<QualityOption>>() }
    var info by remember { mutableStateOf<PageInfo?>(null) }

    LaunchedEffect(Unit) { info = PageMetadata.read(webView) }
    LaunchedEffect(videos.size) {
        videos.toList().forEach { v ->
            if (v.url !in probes) launch { probes[v.url] = VideoProbe.probe(v, userAgent, pageUrl) }
        }
    }

    // A stream's own quality playlists also get detected; hide those so each video shows once.
    val visible = videos.toList().filter { v ->
        probes.none { (k, opts) -> k != v.url && opts.any { it.url == v.url } }
    }
    val baseName = info?.let { PageMetadata.buildName(it) }?.takeIf { it.isNotBlank() } ?: pageTitle.ifBlank { "video" }
    fun nameOf(i: Int) = if (visible.size > 1) "$baseName - ${i + 1}" else baseName
    fun bestOf(v: DetectedVideo) = probes[v.url]?.firstOrNull()

    val allProbed = visible.all { probes.containsKey(it.url) }
    val known = visible.mapNotNull { bestOf(it) }
    val totalBytes = known.sumOf { it.sizeBytes ?: 0L }
    val someUnknown = known.any { it.sizeBytes == null }
    val approx = known.any { it.estimated }
    val totalText = when {
        !allProbed -> "Calculating…"
        totalBytes == 0L -> "Unknown"
        else -> (if (approx) "≈ " else "") + Fmt.size(totalBytes) + if (someUnknown) " +" else ""
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Detected videos") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("${visible.size} video${if (visible.size != 1) "s" else ""}", fontWeight = FontWeight.Medium)
                    Text("Total: $totalText", fontWeight = FontWeight.Medium)
                }
                visible.forEachIndexed { i, v ->
                    val q = bestOf(v)
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(v) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Icon(Icons.Filled.Movie, null, Modifier.size(24.dp).padding(top = 2.dp))
                        Column(Modifier.padding(start = 12.dp)) {
                            Text(nameOf(i), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            Text(
                                listOfNotNull(q?.label, q?.detail).joinToString(" · ").ifEmpty { "Detecting…" },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                Text(
                    "Tap a video to pick its quality or rename it. Download all uses the best quality.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        confirmButton = {
            TextButton(onClick = {
                onDownloadAll(visible.mapIndexed { i, v ->
                    (bestOf(v) ?: QualityOption("Original quality", v.url, v.isHls)) to nameOf(i)
                })
            }) { Text("Download all") }
        },
    )
}
