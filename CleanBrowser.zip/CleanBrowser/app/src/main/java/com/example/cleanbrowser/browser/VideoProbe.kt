package com.example.cleanbrowser.browser

import android.media.MediaMetadataRetriever
import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import kotlin.math.min

/** One selectable quality. [url] is what actually gets downloaded (for HLS: the chosen variant playlist). */
data class QualityOption(
    val label: String,
    val url: String,
    val isHls: Boolean,
    val detail: String? = null,   // "≈ 45.23 MB · 12 min 34 sec"
    val sizeBytes: Long? = null,
    val durationSec: Double? = null,
    val estimated: Boolean = false,
)

/** Finds the available qualities for a detected video, without downloading it. */
object VideoProbe {

    suspend fun probe(video: DetectedVideo, ua: String, referer: String): List<QualityOption> =
        withContext(Dispatchers.IO) {
            runCatching { if (video.isHls) hls(video, ua, referer) else mp4(video, ua, referer) }
                .getOrNull()?.takeIf { it.isNotEmpty() }
                ?: listOf(QualityOption("Original quality", video.url, video.isHls))
        }

    // ---------- HLS ----------

    private class Variant(val w: Int, val h: Int, val bw: Long, val url: String)

    private fun hls(video: DetectedVideo, ua: String, referer: String): List<QualityOption> {
        val text = fetchText(video.url, ua, referer)

        // Plain media playlist: no choices, but we can still read the length.
        if (!text.contains("#EXT-X-STREAM-INF")) {
            return listOf(opt("Original quality", video.url, true, null, duration(text), false))
        }

        val lines = text.lines().map { it.trim() }
        val variants = mutableListOf<Variant>()
        for (i in lines.indices) {
            if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
            val res = Regex("RESOLUTION=(\\d+)x(\\d+)").find(lines[i])
            val avg = Regex("AVERAGE-BANDWIDTH=(\\d+)").find(lines[i])?.groupValues?.get(1)?.toLong()
            val peak = Regex("(?<![A-Z-])BANDWIDTH=(\\d+)").find(lines[i])?.groupValues?.get(1)?.toLong()
            val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
            variants += Variant(
                res?.groupValues?.get(1)?.toInt() ?: 0,
                res?.groupValues?.get(2)?.toInt() ?: 0,
                avg ?: peak ?: 0L,
                URI(video.url).resolve(uri).toString(),
            )
        }

        val sorted = variants
            .groupBy { it.w to it.h }
            .map { (_, g) -> g.maxBy { it.bw } }
            .sortedWith(compareByDescending<Variant> { min(it.w, it.h) }.thenByDescending { it.bw })

        // Every variant has the same length, so read it once from the best one.
        val seconds = sorted.firstOrNull()?.let { runCatching { duration(fetchText(it.url, ua, referer)) }.getOrNull() }

        return sorted.map {
            val label = if (it.w > 0 && it.h > 0) "${min(it.w, it.h)}p (${it.w}x${it.h})" else "Quality ${it.bw / 1000} kbps"
            // HLS doesn't report file size, so it's estimated from bitrate x length.
            val estimate = if (seconds != null && it.bw > 0) (it.bw / 8.0 * seconds).toLong() else null
            opt(label, it.url, true, estimate, seconds, true)
        }
    }

    /** Sum of #EXTINF segment lengths; null for live streams (no #EXT-X-ENDLIST). */
    private fun duration(playlist: String): Double? {
        if (!playlist.contains("#EXT-X-ENDLIST")) return null
        val total = Regex("#EXTINF:([0-9.]+)").findAll(playlist).sumOf { it.groupValues[1].toDouble() }
        return total.takeIf { it > 0 }
    }

    // ---------- MP4 ----------

    private fun mp4(video: DetectedVideo, ua: String, referer: String): List<QualityOption> {
        var size = 0L
        runCatching {
            val c = open(video.url, ua, referer, "HEAD")
            size = c.contentLengthLong
            c.disconnect()
        }

        var w = 0
        var h = 0
        var seconds: Double? = null
        runCatching {
            val headers = mutableMapOf("User-Agent" to ua, "Referer" to referer)
            CookieManager.getInstance().getCookie(video.url)?.let { headers["Cookie"] = it }
            MediaMetadataRetriever().use { r ->
                r.setDataSource(video.url, headers)
                w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                seconds = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.takeIf { it > 0 }?.let { it / 1000.0 }
            }
        }

        val label = when {
            w > 0 && h > 0 -> "${min(w, h)}p (${w}x${h})"
            else -> Regex("(\\d{3,4})[pP]").find(video.url)?.let { "${it.groupValues[1]}p" } ?: "Original quality"
        }
        return listOf(opt(label, video.url, false, size.takeIf { it > 0 }, seconds, false))
    }

    // ---------- formatting ----------

    private fun opt(label: String, url: String, isHls: Boolean, size: Long?, seconds: Double?, estimated: Boolean): QualityOption {
        val parts = listOfNotNull(
            size?.let { (if (estimated) "≈ " else "") + Fmt.size(it) },
            seconds?.let { Fmt.duration(it) },
        )
        return QualityOption(label, url, isHls, parts.joinToString(" · ").ifEmpty { null }, size, seconds, estimated)
    }

    // ---------- network ----------

    private fun open(url: String, ua: String, referer: String, method: String = "GET"): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 8_000
        c.readTimeout = 8_000
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Referer", referer)
        runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()?.let { c.setRequestProperty("Cookie", it) }
        return c
    }

    private fun fetchText(url: String, ua: String, referer: String): String {
        val c = open(url, ua, referer)
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
}
