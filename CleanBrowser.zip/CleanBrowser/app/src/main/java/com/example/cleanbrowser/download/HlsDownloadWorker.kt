package com.example.cleanbrowser.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileDescriptor
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.nio.ByteBuffer

/**
 * Plain (unencrypted, VOD, MPEG-TS segment) HLS -> MP4.
 * 1) pick the highest-bandwidth variant  2) download segments into one .ts
 * 3) remux with MediaExtractor/MediaMuxer (no re-encode) into Downloads via MediaStore.
 */
class HlsDownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    companion object {
        const val TAG = "hls"
        const val CHANNEL = "downloads"
        const val K_URL = "url"
        const val K_REFERER = "referer"
        const val K_UA = "ua"
        const val K_NAME = "name"
        const val K_PROGRESS = "p"
        const val K_OUT_URI = "uri"
        const val K_ERROR = "error"
    }

    private class Unsupported(msg: String) : Exception(msg)

    private val name get() = inputData.getString(K_NAME) ?: "video"

    override suspend fun getForegroundInfo() = info(0, "Starting…")

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val ts = File(applicationContext.cacheDir, "hls_$id.ts")
        try {
            setForeground(info(0, "Reading playlist…"))
            val segments = loadSegments(inputData.getString(K_URL)!!)
            download(segments, ts)
            setForeground(info(100, "Converting to MP4…"))
            val uri = remuxToDownloads(ts)
            Result.success(workDataOf(K_OUT_URI to uri.toString()))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(workDataOf(K_ERROR to (e.message ?: "Download failed")))
        } finally {
            ts.delete()
        }
    }

    // ---------- playlist ----------

    private fun loadSegments(url: String): List<String> {
        var playlistUrl = url
        var text = fetchText(url)

        if (text.contains("#EXT-X-STREAM-INF")) {
            val lines = text.lines().map { it.trim() }
            var bestBw = -1L
            var bestUri: String? = null
            for (i in lines.indices) {
                if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
                val bw = Regex("(?<![A-Z-])BANDWIDTH=(\\d+)").find(lines[i])?.groupValues?.get(1)?.toLong() ?: 0L
                val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
                if (bw > bestBw) { bestBw = bw; bestUri = uri }
            }
            playlistUrl = resolve(url, bestUri ?: throw Unsupported("No video variants found"))
            text = fetchText(playlistUrl)
        }

        val lines = text.lines().map { it.trim() }
        if (lines.any { it.startsWith("#EXT-X-KEY") && !it.contains("METHOD=NONE") })
            throw Unsupported("This stream is encrypted and can't be saved")
        if (lines.any { it.startsWith("#EXT-X-MAP") })
            throw Unsupported("fMP4 streams aren't supported yet")
        if (lines.none { it == "#EXT-X-ENDLIST" })
            throw Unsupported("Live streams aren't supported")

        return lines.filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { resolve(playlistUrl, it) }
            .ifEmpty { throw Unsupported("Playlist has no segments") }
    }

    private fun resolve(base: String, ref: String) = URI(base).resolve(ref).toString()

    // ---------- network ----------

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        inputData.getString(K_UA)?.let { c.setRequestProperty("User-Agent", it) }
        inputData.getString(K_REFERER)?.let { c.setRequestProperty("Referer", it) }
        runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()
            ?.let { c.setRequestProperty("Cookie", it) }
        if (c.responseCode !in 200..299) { c.disconnect(); throw IOException("HTTP ${c.responseCode}") }
        return c
    }

    private fun fetchText(url: String): String {
        val c = open(url)
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    private fun fetchBytes(url: String): ByteArray {
        val c = open(url)
        return try { c.inputStream.readBytes() } finally { c.disconnect() }
    }

    private suspend fun fetchWithRetry(url: String): ByteArray {
        var attempt = 0
        while (true) {
            try { return fetchBytes(url) }
            catch (e: IOException) { if (++attempt >= 3) throw e; delay(1000L * attempt) }
        }
    }

    private suspend fun download(segments: List<String>, out: File) {
        var lastPct = -1
        out.outputStream().buffered().use { os ->
            segments.forEachIndexed { i, seg ->
                currentCoroutineContext().ensureActive()
                os.write(fetchWithRetry(seg)) // written only after a full successful fetch, so retries never corrupt the file
                val pct = (i + 1) * 100 / segments.size
                if (pct != lastPct) {
                    lastPct = pct
                    setProgress(workDataOf(K_PROGRESS to pct))
                    setForeground(info(pct, "$pct%"))
                }
            }
        }
    }

    // ---------- remux ----------

    private fun remuxToDownloads(ts: File): Uri {
        val resolver = applicationContext.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "$name.mp4")
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Couldn't create the output file")
        try {
            resolver.openFileDescriptor(uri, "rw")!!.use { remux(ts.absolutePath, it.fileDescriptor) }
            resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun remux(path: String, fd: FileDescriptor) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            extractor.setDataSource(path)
            muxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val trackMap = HashMap<Int, Int>()
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    trackMap[i] = muxer.addTrack(extractor.getTrackFormat(i))
                }
            }
            if (trackMap.isEmpty()) throw Unsupported("No playable tracks in the stream")
            muxer.start(); started = true

            val buf = ByteBuffer.allocate(2 shl 20)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val size = extractor.readSampleData(buf, 0)
                if (size < 0) break
                val track = trackMap[extractor.sampleTrackIndex]
                if (track != null) {
                    val key = extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0
                    info.set(0, size, extractor.sampleTime.coerceAtLeast(0),
                        if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer.writeSampleData(track, buf, info)
                }
                extractor.advance()
            }
        } finally {
            runCatching { if (started) muxer?.stop() }
            runCatching { muxer?.release() }
            extractor.release()
        }
    }

    // ---------- notification ----------

    private fun info(pct: Int, text: String): ForegroundInfo {
        val ctx = applicationContext
        ctx.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW))
        val cancel = WorkManager.getInstance(ctx).createCancelPendingIntent(id)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(name)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, pct == 0)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(ctx, android.R.drawable.ic_delete), "Cancel", cancel).build())
            .build()
        return ForegroundInfo(id.hashCode(), n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
}
