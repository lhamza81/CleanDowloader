package com.example.cleanbrowser.ui

import android.app.DownloadManager
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.cleanbrowser.browser.Fmt
import com.example.cleanbrowser.download.Downloader
import com.example.cleanbrowser.download.HlsDownloadWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private data class DlItem(
    val id: Long, val title: String, val status: Int,
    val done: Long, val total: Long, val localUri: String?,
)

private fun queryAll(dm: DownloadManager): List<DlItem> =
    dm.query(DownloadManager.Query()).use { c ->
        val out = mutableListOf<DlItem>()
        fun col(n: String) = c.getColumnIndexOrThrow(n)
        while (c.moveToNext()) {
            out += DlItem(
                c.getLong(col(DownloadManager.COLUMN_ID)),
                c.getString(col(DownloadManager.COLUMN_TITLE)).orEmpty(),
                c.getInt(col(DownloadManager.COLUMN_STATUS)),
                c.getLong(col(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                c.getLong(col(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                c.getString(col(DownloadManager.COLUMN_LOCAL_URI)),
            )
        }
        out
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val dm = remember { ctx.getSystemService(DownloadManager::class.java) }
    val wm = remember { WorkManager.getInstance(ctx) }
    var items by remember { mutableStateOf(emptyList<DlItem>()) }
    val hls by wm.getWorkInfosByTagLiveData(HlsDownloadWorker.TAG).observeAsState(emptyList<WorkInfo>())

    LaunchedEffect(Unit) {
        while (true) {
            items = withContext(Dispatchers.IO) { queryAll(dm) }
            delay(1000)
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Downloads") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { padding ->
        val visibleHls = hls.filter { it.state != WorkInfo.State.CANCELLED }
        if (visibleHls.isEmpty() && items.isEmpty()) {
            Text("No downloads yet", modifier = Modifier.padding(padding).padding(24.dp))
        }
        LazyColumn(Modifier.padding(padding)) {
            items(visibleHls, key = { it.id }) { w ->
                val name = w.tags.firstOrNull { it.startsWith("name:") }?.removePrefix("name:") ?: "Video"
                val finished = w.state.isFinished
                val savedUri = w.outputData.getString(HlsDownloadWorker.K_OUT_URI)?.let { Uri.parse(it) }
                val pct = w.progress.getInt(HlsDownloadWorker.K_PROGRESS, 0)
                DownloadRow(
                    title = "$name.mp4",
                    uri = savedUri,
                    fallbackSize = null,
                    status = when (w.state) {
                        WorkInfo.State.RUNNING -> "Downloading $pct%"
                        WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> "Waiting for network…"
                        WorkInfo.State.FAILED -> w.outputData.getString(HlsDownloadWorker.K_ERROR) ?: "Failed"
                        else -> null
                    },
                    progress = if (w.state == WorkInfo.State.RUNNING) pct / 100f else null,
                    onOpen = savedUri?.let { u -> { Downloader.openVideo(ctx, u) } },
                    onRemove = { if (finished) wm.pruneWork() else wm.cancelWorkById(w.id) },
                )
                HorizontalDivider()
            }
            items(items, key = { it.id }) { d ->
                val done = d.status == DownloadManager.STATUS_SUCCESSFUL
                val uri = remember(d.id, done) {
                    if (done) runCatching { dm.getUriForDownloadedFile(d.id) }.getOrNull() else null
                }
                val fileName = d.localUri?.let { Uri.parse(it).lastPathSegment } ?: "${d.title}.mp4"
                DownloadRow(
                    title = fileName,
                    uri = uri,
                    fallbackSize = d.total.takeIf { done && it > 0 },
                    status = when (d.status) {
                        DownloadManager.STATUS_SUCCESSFUL -> null
                        DownloadManager.STATUS_FAILED -> "Failed"
                        DownloadManager.STATUS_PAUSED -> "Paused"
                        DownloadManager.STATUS_PENDING -> "Waiting…"
                        else -> "${Fmt.size(d.done)} / " + if (d.total > 0) Fmt.size(d.total) else "?"
                    },
                    progress = if (d.status == DownloadManager.STATUS_RUNNING && d.total > 0)
                        d.done.toFloat() / d.total else null,
                    onOpen = if (done && uri != null) ({ Downloader.openVideo(ctx, uri) }) else null,
                    onRemove = { dm.remove(d.id) },
                )
                HorizontalDivider()
            }
        }
    }
}

/** One video per line: preview, full name, size and length. */
@Composable
private fun DownloadRow(
    title: String,
    uri: Uri?,
    fallbackSize: Long?,
    status: String?,
    progress: Float?,
    onOpen: (() -> Unit)?,
    onRemove: () -> Unit,
) {
    val info by rememberMediaInfo(uri)
    val frame = info?.frame
    val meta = listOfNotNull(
        (info?.sizeBytes ?: fallbackSize)?.let { Fmt.size(it) },
        info?.durationSec?.let { Fmt.duration(it) },
    ).joinToString(" · ")

    Row(
        Modifier.fillMaxWidth()
            .clickable(enabled = onOpen != null) { onOpen?.invoke() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            Modifier.width(112.dp).height(72.dp).clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center,
        ) {
            if (frame != null) {
                Image(frame.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Icon(Icons.Filled.PlayArrow, null, Modifier.size(30.dp), tint = Color.White)
            } else {
                Icon(if (uri != null) Icons.Filled.PlayArrow else Icons.Filled.Download, null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium) // full name
            if (meta.isNotEmpty()) Text(meta, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (status != null) Text(status, style = MaterialTheme.typography.bodySmall)
            if (progress != null) LinearProgressIndicator(
                progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        }
        IconButton(onClick = onRemove) { Icon(Icons.Filled.Delete, "Remove") }
    }
}
