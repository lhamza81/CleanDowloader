package com.example.cleanbrowser.browser

import android.net.Uri

object VideoDetector {
    /** Classifies a request URL by its path (query string ignored). Safe to call off the main thread. */
    fun classify(url: String): DetectedVideo? {
        val path = Uri.parse(url).path?.lowercase() ?: return null
        return when {
            path.endsWith(".mp4") -> DetectedVideo(url, isHls = false)
            path.endsWith(".m3u8") -> DetectedVideo(url, isHls = true)
            else -> null
        }
    }
}
